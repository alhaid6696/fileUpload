
# =========================================================
# Deep Q-Network (DQN) Implementation for CartPole-v1
# Course: COEN 874 - Reinforcement Learning
# =========================================================

import gym
import numpy as np
import random
from collections import deque
import matplotlib.pyplot as plt

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

# -------------------------------
# Environment Setup
# -------------------------------
env = gym.make("CartPole-v1")
state_size = env.observation_space.shape[0]
action_size = env.action_space.n

# -------------------------------
# Hyperparameters
# -------------------------------
episodes = 500
batch_size = 64
gamma = 0.99
learning_rate = 0.001

epsilon = 1.0
epsilon_decay = 0.995
epsilon_min = 0.01

memory_size = 20000

# -------------------------------
# Experience Replay Buffer
# -------------------------------
memory = deque(maxlen=memory_size)

# -------------------------------
# Build Q-Network
# -------------------------------
def build_model():
    model = Sequential()
    model.add(Dense(24, input_dim=state_size, activation='relu'))
    model.add(Dense(24, activation='relu'))
    model.add(Dense(action_size, activation='linear'))
    model.compile(loss='mse', optimizer=Adam(learning_rate=learning_rate))
    return model

# Main network and target network
model = build_model()
target_model = build_model()
target_model.set_weights(model.get_weights())

# -------------------------------
# Helper Functions
# -------------------------------
def remember(state, action, reward, next_state, done):
    memory.append((state, action, reward, next_state, done))

def act(state):
    global epsilon
    if np.random.rand() <= epsilon:
        return random.randrange(action_size)
    q_values = model.predict(state, verbose=0)
    return np.argmax(q_values[0])

def replay():
    global epsilon
    if len(memory) < batch_size:
        return

    minibatch = random.sample(memory, batch_size)

    states = []
    targets = []

    for state, action, reward, next_state, done in minibatch:
        target = model.predict(state, verbose=0)[0]
        if done:
            target[action] = reward
        else:
            t = target_model.predict(next_state, verbose=0)[0]
            target[action] = reward + gamma * np.amax(t)

        states.append(state[0])
        targets.append(target)

    model.fit(np.array(states), np.array(targets), epochs=1, verbose=0)

    if epsilon > epsilon_min:
        epsilon *= epsilon_decay

# -------------------------------
# Training Loop
# -------------------------------
episode_rewards = []
target_update_freq = 10

for episode in range(episodes):
    state, _ = env.reset()
    state = np.reshape(state, [1, state_size])
    total_reward = 0
    done = False

    while not done:
        action = act(state)
        next_state, reward, done, truncated, _ = env.step(action)
        next_state = np.reshape(next_state, [1, state_size])

        remember(state, action, reward, next_state, done)
        state = next_state
        total_reward += reward

        replay()

    episode_rewards.append(total_reward)

    if episode % target_update_freq == 0:
        target_model.set_weights(model.get_weights())

    if (episode + 1) % 50 == 0:
        print(f"Episode {episode + 1}, Average Reward: {np.mean(episode_rewards[-50:]):.2f}")

# -------------------------------
# Plot Results
# -------------------------------
plt.figure()
plt.plot(episode_rewards)
plt.xlabel("Episodes")
plt.ylabel("Cumulative Reward")
plt.title("DQN Performance on CartPole-v1")
plt.show()

env.close()
